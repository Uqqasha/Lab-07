package com.Uqqasha.Lab_07;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table (name = "per")
public class Person {
	
	@Id
	private int id;
	private String name;
	private String father_name;
	private String organization;
	private String mobile;
	
	public Person() {}
	
	void setId(int id) {
		this.id = id;
	}
	int getId() {
		return id;
	}
	
	void setname(String fname) {
		name = fname;
	}
	String getname() {
		return name;
	}
	
	void setFather_name(String lname) {
		father_name = lname;
	}
	String getFather_name() {
		return father_name;
	}
	
	void setOrganization(String org) {
		organization = org;
	}
	String getOrganization() {
		return organization;
	}
	
	void setMobile(String mob) {
		mobile = mob;
	}
	String getMobile() {
		return mobile;
	}

}

